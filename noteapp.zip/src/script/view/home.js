// import Notes from '../data/local/notesData.js';

// const home = () => {
// }