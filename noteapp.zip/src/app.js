import './script/components/index.js';

// import home from './script/view/home.js';

document.addEventListener('DOMContentLoaded', () => {
    // home();
});